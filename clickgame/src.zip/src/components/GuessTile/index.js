export { default } from "./GuessTile";
